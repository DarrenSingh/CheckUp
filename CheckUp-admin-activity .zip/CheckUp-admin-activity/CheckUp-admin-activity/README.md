# Foobar

CheckUp is a mobile application developed for the Android using Java language.

The apps core functionality allows: 

- Patients to search for nearby Doctors and either submit non-emergency inquiries or request appointments based on their availability. 

- Doctors to view upcoming appointments with their patients, read and respond to patient inquiries 

- Administrators to create user accounts, and handle general account responsibilities such as password resets.

- Cashiers to payment process.


## Contributers
Developed by: 
- [Darren Singh](https://github.com/DarrenSingh)
- [Shivangi Patel](https://github.com/IR0NM9N)
- [Bokki Min](https://github.com/ama-cantabile)
- [Tonny Ogange](https://github.com/t-iro)


