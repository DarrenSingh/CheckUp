package com.Group6.checkup;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ViewUserHistoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_user_history);
    }
}
