package com.Group6.checkup.AppMaintenancePackage;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.Group6.checkup.R;


public class AppMaintenanceActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_maintenance);
    }
}
